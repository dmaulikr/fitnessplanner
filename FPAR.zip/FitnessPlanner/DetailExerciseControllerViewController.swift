//
//  DetailExerciseControllerViewController.swift
//  FitnessPlanner
//
//  Created by Nicholas Zustak on 11/20/16.
//  Copyright © 2016 CSM. All rights reserved.
//

import UIKit

class DetailExerciseControllerViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var numSets = 0
    var numReps = 0
    var cellsSelected = [Bool]()
    @IBOutlet weak var tblView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        cellsSelected = Array(repeating: false, count: numSets)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numSets
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath:
        IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier:
            "setCell")
        
        if cell == nil {
            print("Need to create a new setCell")
            cell = UITableViewCell(style: UITableViewCellStyle.default,
                                   reuseIdentifier: "setCell")
        }
        
        cell?.textLabel?.text = "Set \(indexPath.row + 1): \(numReps) reps"
        return cell!
    }
    
//    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
//        if let cell = tableView.cellForRow(at: indexPath) {
//            cell.accessoryType = .none
//        }
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if(!cellsSelected[indexPath.row]) {
                ProgressBar.PBInstance.setsCompleted += 1
            }
            cellsSelected[indexPath.row] = true
            cell.accessoryType = .checkmark
        }
    }
    
    func clearCheckMarks(_ tableView: UITableView) {
        for cell in tableView.visibleCells {
            if (cell.accessoryType == UITableViewCellAccessoryType.checkmark) {
                ProgressBar.PBInstance.setsCompleted -= 1
            }
            cell.accessoryType = .none
        }
    }
    
    @IBAction func resetTapped(_ sender: Any) {
        clearCheckMarks(tblView)
    }

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
    }
    

}
